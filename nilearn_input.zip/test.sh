DIR=~/nilearn_data/neurovault/collection_658/
cp -r collection_metadata.json image_10426_metadata.json image_10426.nii.gz $DIR/.
python3 plot_3d_and_4d_niimg_nogui.py
